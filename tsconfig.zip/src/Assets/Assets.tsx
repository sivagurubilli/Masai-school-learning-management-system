export const masaiimage: string = 'https://masaischool.com/img/navbar/logo.svg';
export const recaptchasitekey: string = "6LcL1IYkAAAAAOpjnAkBX46h3M2Z3HS7a6mDBndW";
export const reacptchasecret: string = "6LcL1IYkAAAAANf6T89oYeZtG-RbKeBCjFpXSK61";
export const referAndEarnLink: string = "https://www.masaischool.com/referral/";
export const sprintplanlink: string = "https://lookerstudio.google.com/embed/reporting/eb648c7e-0ebe-4ace-be9f-05f85449c32a/page/QHo9C"

export const gifloader = "https://media.tenor.com/7JONloO2xawAAAAM/loading-screen-loading.gif"
export const batchValues =[
    
    { value: "ftweb20", label: "FT_WEB_20" },
{ value: "ftweb21", label: "FT_WEB_21" },
{ value: "ftweb22", label: "FT_WEB_22" },
{ value: "ftweb23", label: "FT_WEB_23" },
{ value: "ftweb24", label: "FT_WEB_23" },
{ value: "ftweb25", label: "FT_WEB_23" },

]

export const sectionValues =[
    
    { value: "js101", label: "js10" },
{ value: "js211", label: "js211" },
{ value: "dsa211", label: "dsa211" },
{ value: "dsa101", label: "dsa101" },
{ value: "dsa421", label: "dsa421" },
{ value: "rct101", label: "rct101" },
{ value: "rct211", label: "rct211" },
]


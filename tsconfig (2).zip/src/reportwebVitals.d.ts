declare module 'reportWebVitals' {
    export function getCLS(onReport: (metric: any) => void): void;
    export function getFID(onReport: (metric: any) => void): void;
    export function getFCP(onReport: (metric: any) => void): void;
    export function getLCP(onReport: (metric: any) => void): void;
    export function getTTFB(onReport: (metric: any) => void): void;
  }
  
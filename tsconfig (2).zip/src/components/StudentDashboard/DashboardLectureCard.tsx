import React from 'react'

const DashboardLectureCard = () => {



  return (
    <div>
DashboardLectureCard


    </div>
  )
}

export default DashboardLectureCard